document.addEventListener('DOMContentLoaded', function() {
    const filtroBtns = document.querySelectorAll('.filtro-btn');
    
    filtroBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove classe active de todos os botões
            filtroBtns.forEach(b => b.classList.remove('active'));
            // Adiciona classe active apenas no botão clicado
            this.classList.add('active');
            
            // Aqui você implementaria a lógica de filtragem
            // const categoria = this.textContent;
            // filtrarProdutos(categoria);
        });
    });
});