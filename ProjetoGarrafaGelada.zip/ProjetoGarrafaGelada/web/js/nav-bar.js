document.addEventListener('DOMContentLoaded', function() {
    // Menu toggle for mobile
    const menuToggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('nav ul');
    const sidebar = document.querySelector('.sidebar');

    menuToggle.addEventListener('click', function() {
        nav.classList.toggle('active');
        sidebar.classList.toggle('active');
    });

    // Close sidebar when clicking outside
    document.addEventListener('click', function(e) {
        if (!sidebar.contains(e.target) && e.target !== menuToggle && !nav.contains(e.target)) {
            sidebar.classList.remove('active');
            nav.classList.remove('active');
        }
    });

    // Prevent sidebar click from closing immediately
    sidebar.addEventListener('click', function(e) {
        e.stopPropagation();
    });

    // Highlight current page in navigation
    const currentPage = location.pathname.split('/').pop();
    document.querySelectorAll('nav a, .sidebar a').forEach(link => {
        if (link.getAttribute('href') === currentPage) {
            link.classList.add('active');
        }
    });
});