/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Gustavo Pedro
 * Created: 10/04/2024
 */

CREATE TABLE produto (
	idProduto SERIAL NOT NULL,
	nomeProduto VARCHAR(200) NOT NULL,
	descricaoProduto VARCHAR(200) NOT NULL,
	precoProduto NUMERIC(12,2) NOT NULL,
	quantEstoque INT NOT NULL,
	CONSTRAINT pk_produto PRIMARY KEY (idProduto)
);

