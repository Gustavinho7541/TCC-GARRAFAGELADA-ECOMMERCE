/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.projetogarrafagelada.DAO;

import br.com.projetogarrafagelada.model.Produto;
import br.com.projetogarrafagelada.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gustavo
 */
public class ProdutoDAO {
    
    //Criando uma VARIAVEL chamada conexao
    private final Connection conexao;

    //Abrindo a conexão com o banco
    public ProdutoDAO() throws ClassNotFoundException, SQLException {
        conexao = Conexao.abrirConexao();
    }
    
    /* Método criado para verificar se um usuário quer cadastrar
    um novo registro ou alterar já existente.  */
    public void gravar(Object object) throws SQLException {
        //Criando um novo objeto do tipo PRODUTO
        Produto produto = (Produto) object;
        /* Verificando se o código Aluno é igual a 0
        Caso Verdadeiro - chama o método INSERIR
        Caso Falso - chama o método ALTERAR
         */
        if (produto.getIdProduto() == 0) {
            
            this.inserir(produto);
        } else {
            
            this.alterar(produto);
        }
    }
    
    public void inserir(Object object) throws SQLException {
        //Variável sql que armazena o comando que será rodado no banco da dados
        String sql = "INSERT INTO produto VALUES (default, ?, ?, ?, ?)";
        // Criar um objeto que será inserido no banco de dados
        Produto produto = (Produto) object;
        /* O método PreparedStatement é usado para criar um  objeto
        que representa a instrução SQL que será executada no banco. */
        PreparedStatement stmt = null;
        //Tratamento de Exceção - Try / Catch
        try {
            stmt = conexao.prepareStatement(sql);
            stmt.setString(1, produto.getNomeProduto());
            stmt.setString(2, produto.getDescricaoProduto());
            stmt.setDouble(3, produto.getPrecoProduto());
            stmt.setInt(4, produto.getQuantEstoque());
            stmt.execute();
        } catch (SQLException ex) {
            //Mostrar os erros para o programador
            System.out.println("ERRO na DAO ao Cadastrar Produto! ERRO: " + ex.getMessage());
            //Mostrar uma pilha de erros
            ex.printStackTrace();
            throw new SQLException("ERRO na DAO ao INSERIR Produto!");
        } finally {
            Conexao.encerrarConexao(conexao, stmt);
        }
    }
    
    public List<Object> listar() throws SQLException {
      //Variável sql que armazena o comando que será rodado no banco de dados 
      String sql = "SELECT * FROM produto ORDER BY idProduto;";
      PreparedStatement stmt= null;
      /*
           ResultSet - É uma classe utilizada para representar um conjunto de 
      resultados de uma consulta SQL executada em um banco de dados.
      */
      ResultSet rs = null;
      /*PERGUNTA DE PROVA:
        ResultSet rs + null;
        Qual o tipo da variável rs? R: ResultsSet.
        Qual é o nome da variável do tipo ResultSet? R: rs.
        Qual o valor da variável rs? R: null.
      */
      List<Object> lista = new ArrayList<>();
      try {
          stmt = conexao.prepareStatement(sql);
          rs = stmt.executeQuery();
          //Laço de repetição
          while (rs.next()) {
              Produto produto = new Produto(rs.getInt("idProduto"),
                      rs.getString("nomeProduto"), 
                      rs.getString("descricaoProduto"), 
                      rs.getDouble("precoProduto"),
                      rs.getInt("quantEstoque"));
                      lista.add(produto);
          }
      } catch (SQLException ex){
          //Pergunta de Prova: Qual o método usado para mostrar uma pilha de erros?
          throw new SQLException ("Erro na DAO ao listar Produto! " + ex.getMessage()); 
      } finally {
          Conexao.encerrarConexao(conexao, stmt, rs);
      }
      return lista;
    }
    
    private void alterar(Object objeto) throws SQLException {
        String sql = "UPDATE produto SET nomeProduto = ?, descricaoProduto = ?, precoProduto = ?, " 
               + " quantEstoque  = ? WHERE idProduto = ?;";
        
        Produto produto = (Produto) objeto;
        PreparedStatement stmt = null;
        try {
            stmt = conexao.prepareStatement(sql);
            stmt.setString(1, produto.getNomeProduto());
            stmt.setString(2, produto.getDescricaoProduto());
            stmt.setDouble(3, produto.getPrecoProduto());
            stmt.setInt(4, produto.getQuantEstoque());
            stmt.setInt(5, produto.getIdProduto());
            stmt.execute();
        } catch (SQLException ex){
            ex.printStackTrace();
              System.out.println("ERRO na Controller ao Alterar Produto! ERRO: " + ex.getMessage());
            throw new SQLException("ERRO ao alterar Produto!");
        } finally {
            Conexao.encerrarConexao(conexao, stmt);
        }
    }
    
    public void excluir (int codigo) throws SQLException {
        String sql = "DELETE FROM produto WHERE idProduto = ?";
        PreparedStatement stmt = null;
        try {
            stmt = conexao.prepareStatement (sql);
            stmt.setInt (1, codigo);
            stmt.execute();
        } catch(SQLException ex) {
            System.out.println("Erro na DAO ao excluir Produto! ERRO: " + ex.getMessage());
            ex.printStackTrace();
            throw new SQLException("Erro na DAO ao Excluir Produto!");
            
        }  finally {
            Conexao.encerrarConexao(conexao, stmt);
        }
    }
    
     public Object consultar(int codigo) throws SQLException {
            String sql = "SELECT * FROM produto WHERE idProduto = ?;";
            PreparedStatement stmt = null;
            ResultSet rs = null;
            Produto produto = null;
            try {
                stmt = conexao.prepareStatement(sql);
                stmt.setInt (1, codigo);
                rs = stmt.executeQuery();
                while (rs.next()) {
                    produto = new Produto (rs.getInt("idProduto"),
                      rs.getString("nomeProduto"), 
                      rs.getString("descricaoProduto"), 
                      rs.getDouble("precoProduto"),
                      rs.getInt("quantEstoque"));          
                }
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Problemas na DAO ao Consultar Aluno! ERRO: " + ex.getMessage());
            throw new SQLException ("Erro ao consultar Aluno!");
            
        } finally {
                Conexao.encerrarConexao(conexao, stmt, rs);
        }
        return produto;
        
    }
    
}
